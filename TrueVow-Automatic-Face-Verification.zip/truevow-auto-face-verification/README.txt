TRUEVOW AUTOMATIC FACE MATCHING — DEPLOYMENT PACK
================================================

WHAT THIS ADDS
- The existing TrueVow HTML keeps its current app features and layout.
- After the existing 3-minute first-use period, the verification gate blocks the app UI.
- The selfie is sent to a separate Node.js backend with the user's Firebase sign-in token.
- The backend reads that user's profile photos from Firestore, detects faces, and compares face descriptors.
- If the selfie matches one of up to six Cloudinary profile photos (starting threshold 0.48), the backend sets faceVerificationStatus=approved. If not, it sets rejected and the user can try again.
- The selfie itself is processed in memory and is not saved by this backend.

IMPORTANT LIMITATIONS
- This is face similarity matching, not proof of legal identity and not robust liveness/anti-spoofing. A photo or screen replay may fool a basic selfie upload. Do not advertise this as government-ID verification or guaranteed liveness detection.
- The 0.48 threshold is a starting value and must be tested with real users, varied lighting, camera quality, and skin tones before launch. False matches and false rejections are possible. Provide a support/manual appeal route.
- Face data is sensitive biometric information. Before launch, publish a clear privacy notice, obtain explicit consent, define retention/deletion, restrict staff access, and check applicable Nigerian data-protection requirements.
- The front-end 3-minute overlay can be bypassed by a technically skilled user. Real access enforcement requires Firestore Security Rules / backend checks for every protected operation (discover, likes, matches, chats, etc.). Do not rely on the overlay alone.
- The backend accepts profile photo URLs only from res.cloudinary.com. If your profile images are hosted elsewhere, adjust that allowlist deliberately.

PART 1 — DEPLOY THE BACKEND (REQUIRED FOR AUTOMATIC MATCHING)
1. Create a private GitHub repository and upload the contents of this backend folder.
2. Create a Firebase service account:
   Firebase Console -> Project settings -> Service accounts -> Generate new private key.
   Keep the downloaded JSON private. NEVER put it in the GitHub repository or HTML.
3. Create a Render Web Service from that backend repository.
   Runtime: Node
   Build command: npm install && npm run download-models
   Start command: npm start
   Node version: 20 or 22
   The included Aptfile lists native libraries needed by node-canvas on supported build systems.
4. Add these environment variables in Render:
   FIREBASE_SERVICE_ACCOUNT_JSON = the entire service-account JSON on one line
   ALLOWED_ORIGINS = https://YOUR-GITHUB-PAGES-DOMAIN,https://YOUR-CUSTOM-DOMAIN
   NODE_ENV = production
5. Deploy. Test https://YOUR-RENDER-SERVICE.onrender.com/health . It should return {"ok":true,"modelsReady":true}.
6. In the HTML file, find:
   const TRUEVOW_FACE_API_URL = "https://YOUR-TRUEVOW-FACE-API.onrender.com";
   Replace it with your real Render URL (without /verify-face).
7. Upload the updated HTML to your GitHub Pages repository and publish it.

PART 2 — FIRESTORE SECURITY (DO NOT SKIP)
Your existing Firestore rules were not included in the supplied HTML, so this pack does not overwrite them. In your existing /users/{userId} rules, prevent the signed-in user from writing verification fields themselves. Add these protected fields to your existing create/update validation:

Protected fields:
faceVerificationStatus
faceVerificationMethod
faceVerificationMatchDistance
faceVerificationComparedPhotos
faceVerificationReviewedAt
faceVerificationSubmittedAt

For user self-updates, reject any write where request.resource.data.diff(resource.data).affectedKeys() has any of those fields. For user creation, reject documents containing any of those fields. The Admin SDK backend bypasses client rules and can write the result. Preserve your existing rules for all other fields and collections; do not replace the whole rules file with a guessed template.

Also enforce approved status in the rules for every protected collection/action your app uses (likes, matches, messages, chat typing, profile discovery reads, etc.). The exact paths and existing rules must be reviewed before writing those rules. Otherwise a user may bypass the visual gate by calling Firebase directly.

HOW TO TEST
- Use a test account with at least one clear, front-facing face photo in its TrueVow profile.
- Wait for the 3-minute gate, take a new selfie, and submit.
- Matching face: Firestore user document should show faceVerificationStatus = approved and access should reopen.
- Different person: status should be rejected and the gate should remain.
- No face / multiple faces / no usable profile photo: request should fail closed and explain what to fix.

TROUBLESHOOTING
- /health modelsReady false: model download/build did not complete; check Render build logs.
- "Automatic verification server is not connected yet": replace TRUEVOW_FACE_API_URL in the HTML.
- CORS error: add the exact deployed GitHub Pages/custom domain to ALLOWED_ORIGINS and redeploy.
- Firebase token error: ensure service account belongs to the same Firebase project used by the HTML (projectId joblink-d3d17).
- Profile photo could not be read: confirm the user's photos are valid public Cloudinary HTTPS image URLs.
