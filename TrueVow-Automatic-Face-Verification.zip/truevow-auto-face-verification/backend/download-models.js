const fs = require('fs');
const path = require('path');
const https = require('https');
const dir = path.join(__dirname, 'models');
fs.mkdirSync(dir, { recursive: true });
const files = [
  'tiny_face_detector_model-weights_manifest.json',
  'tiny_face_detector_model-shard1',
  'face_landmark_68_model-weights_manifest.json',
  'face_landmark_68_model-shard1',
  'face_recognition_model-weights_manifest.json',
  'face_recognition_model-shard1',
  'face_recognition_model-shard2'
];
function download(file) {
  return new Promise((resolve, reject) => {
    const url = `https://raw.githubusercontent.com/vladmandic/face-api/master/model/${file}`;
    const target = path.join(dir, file);
    const request = https.get(url, response => {
      if (response.statusCode !== 200) return reject(new Error(`Download failed for ${file}: HTTP ${response.statusCode}`));
      const stream = fs.createWriteStream(target);
      response.pipe(stream);
      stream.on('finish', () => stream.close(resolve));
      stream.on('error', reject);
    });
    request.on('error', reject);
  });
}
(async () => {
  for (const file of files) { console.log(`Downloading ${file}`); await download(file); }
  console.log('Face models downloaded.');
})().catch(err => { console.error(err); process.exit(1); });
