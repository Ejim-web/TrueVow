const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const admin = require('firebase-admin');
const faceapi = require('@vladmandic/face-api');
const tf = require('@tensorflow/tfjs-node');
const canvas = require('canvas');
const path = require('path');

const { Canvas, Image, ImageData, loadImage } = canvas;
faceapi.env.monkeyPatch({ Canvas, Image, ImageData });

if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
  throw new Error('Set FIREBASE_SERVICE_ACCOUNT_JSON to the Firebase service-account JSON string.');
}
const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

const app = express();
app.set('trust proxy', 1);
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) {
  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) return cb(null, true);
  return cb(new Error('Origin not allowed'));
}}));
app.use(express.json({ limit: '12mb' }));
app.use('/verify-face', rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false }));

let modelsReady = false;
async function loadModels() {
  if (modelsReady) return;
  const modelPath = path.join(__dirname, 'models');
  await faceapi.nets.tinyFaceDetector.loadFromDisk(modelPath);
  await faceapi.nets.faceLandmark68Net.loadFromDisk(modelPath);
  await faceapi.nets.faceRecognitionNet.loadFromDisk(modelPath);
  modelsReady = true;
}

async function getDescriptor(imageBuffer) {
  const img = await loadImage(imageBuffer);
  const result = await faceapi.detectAllFaces(img, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 }))
    .withFaceLandmarks().withFaceDescriptors();
  if (result.length !== 1) {
    const err = new Error(result.length === 0 ? 'No face found. Take a clear selfie.' : 'More than one face found. Only you should be in the selfie.');
    err.status = 422;
    throw err;
  }
  return result[0].descriptor;
}

function parseImageData(value) {
  if (typeof value !== 'string' || !value.startsWith('data:image/')) throw Object.assign(new Error('A camera selfie is required.'), { status: 400 });
  const match = value.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/i);
  if (!match) throw Object.assign(new Error('Unsupported image. Use JPEG, PNG, or WebP.'), { status: 400 });
  const buffer = Buffer.from(match[2], 'base64');
  if (buffer.length > 8 * 1024 * 1024) throw Object.assign(new Error('Selfie must be under 8MB.'), { status: 413 });
  return buffer;
}

app.get('/health', (_req, res) => res.json({ ok: true, modelsReady }));
app.post('/verify-face', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
    if (!token) return res.status(401).json({ ok: false, message: 'Sign in is required.' });
    const decoded = await admin.auth().verifyIdToken(token);
    const uid = decoded.uid;
    const selfieBuffer = parseImageData(req.body && req.body.selfie);
    await loadModels();

    const userRef = db.collection('users').doc(uid);
    const userSnap = await userRef.get();
    if (!userSnap.exists) return res.status(404).json({ ok: false, message: 'Your TrueVow profile was not found.' });
    const profile = userSnap.data() || {};
    const photos = Array.isArray(profile.photos) ? profile.photos.filter(p => { try { return typeof p === 'string' && new URL(p).hostname === 'res.cloudinary.com' && new URL(p).protocol === 'https:'; } catch (_) { return false; } }).slice(0, 6) : [];
    if (!photos.length) return res.status(422).json({ ok: false, message: 'Add at least one clear face photo to your profile before verifying.' });

    const selfieDescriptor = await getDescriptor(selfieBuffer);
    let bestDistance = Infinity;
    let compared = 0;
    for (const url of photos) {
      try {
        const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (!response.ok) continue;
        const imageBuffer = Buffer.from(await response.arrayBuffer());
        if (imageBuffer.length > 10 * 1024 * 1024) continue;
        const profileDescriptor = await getDescriptor(imageBuffer);
        const distance = faceapi.euclideanDistance(selfieDescriptor, profileDescriptor);
        compared++;
        if (distance < bestDistance) bestDistance = distance;
      } catch (e) {
        // Skip profile images that cannot be downloaded or do not contain exactly one face.
      }
    }
    if (!compared) return res.status(422).json({ ok: false, message: 'We could not find a clear single face in your profile photos. Add a clear photo and try again.' });

    // 0.48 is a conservative starting threshold; tune with real-world testing before launch.
    const matched = bestDistance <= 0.48;
    await userRef.set({
      faceVerificationStatus: matched ? 'approved' : 'rejected',
      faceVerificationMethod: 'automatic-face-match',
      faceVerificationMatchDistance: Number(bestDistance.toFixed(4)),
      faceVerificationComparedPhotos: compared,
      faceVerificationReviewedAt: admin.firestore.FieldValue.serverTimestamp(),
      faceVerificationSubmittedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    return res.json({
      ok: true,
      approved: matched,
      status: matched ? 'approved' : 'rejected',
      message: matched ? 'Your selfie matches your TrueVow profile photo. Verification approved.' : 'Your selfie did not match your profile photos. Please try again with a clear, front-facing selfie and a clear profile photo.'
    });
  } catch (error) {
    console.error('Face verification error:', error.message);
    return res.status(error.status || 500).json({ ok: false, message: error.status ? error.message : 'Automatic verification is temporarily unavailable. Please try again later.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`TrueVow face verification API listening on ${port}`));
